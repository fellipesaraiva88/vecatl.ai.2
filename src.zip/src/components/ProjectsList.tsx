import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import CreateTaskModal from './CreateTaskModal';
import ProjectDialog from './ProjectDialog';
import './DialogStyles.module.css';

const ProjectsContainer = styled.div``;
const Title = styled.h2`
  font-size: 1.5em;
  margin-bottom: 24px;
  font-weight: 600;
`;
const ProjectCard = styled.div`
  background: var(--card-bg);
  padding: 20px;
  border: 1px solid var(--card-border);
  border-radius: var(--card-radius);
  box-shadow: var(--card-shadow);
  margin-bottom: 16px;
  font-weight: 500;
  display: flex;
  align-items: center;
  justify-content: space-between;
`;
const AddProjectForm = styled.form`
  display: flex;
  gap: 8px;
  margin-bottom: 24px;
`;
const AddInput = styled.input`
  flex: 1;
`;
const AddButton = styled.button`
  background: var(--primary);
  color: #fff;
  border-radius: 8px;
  padding: 8px 18px;
  font-weight: 500;
  font-size: 15px;
`;
const DeleteButton = styled.button`
  background: #e74c3c;
  color: #fff;
  border-radius: 8px;
  padding: 4px 10px;
  font-size: 13px;
  margin-left: 16px;
`;
const NewTaskButton = styled.button`
  background: var(--primary);
  color: #fff;
  border-radius: 8px;
  padding: 8px 18px;
  font-weight: 500;
  font-size: 15px;
  margin-top: 16px;
`;

const ProjectsList = () => {
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [newProject, setNewProject] = useState('');
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [showCreateTask, setShowCreateTask] = useState(false);
  const [showProjectDialog, setShowProjectDialog] = useState(false);

  const fetchProjects = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/projects');
      const data = await res.json();
      setProjects(data);
    } catch {
      setError('Failed to load projects.');
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProject.trim()) return;
    try {
      await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newProject }),
      });
      setNewProject('');
      fetchProjects();
    } catch {
      setError('Failed to add project.');
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await fetch('/api/projects', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      fetchProjects();
    } catch {
      setError('Failed to delete project.');
    }
  };

  const handleProjectClick = (project: any) => {
    setSelectedProject(project);
  };

  const handleCreateTask = async (taskData: any) => {
    try {
      const response = await fetch('/api/tasks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...taskData,
          projectId: selectedProject?.id,
        }),
      });

      if (response.ok) {
        // Refresh project data
        const projectResponse = await fetch('/api/projects');
        const updatedProjects = await projectResponse.json();
        setProjects(updatedProjects);
      }
    } catch (error) {
      console.error('Failed to create task:', error);
    }
    setShowCreateTask(false);
  };

  const handleAddProjectClick = () => {
    setShowProjectDialog(true);
  };

  return (
    <ProjectsContainer>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Title>📁 Projects</Title>
        <AddButton onClick={handleAddProjectClick}>Add Project</AddButton>
      </div>
      {showProjectDialog && (
        <ProjectDialog
          onClose={() => setShowProjectDialog(false)}
          onCreate={(project) => console.log('Project created:', project)}
        />
      )}
      {loading && <div>Loading...</div>}
      {error && <div style={{ color: 'red' }}>{error}</div>}
      {!loading && projects.length === 0 && (
        <div style={{ color: '#888' }}>No projects yet.</div>
      )}
      {projects.map(project => (
        <ProjectCard key={project.id} onClick={() => handleProjectClick(project)}>
          {project.name}
          <DeleteButton
            onClick={e => {
              e.stopPropagation();
              handleDelete(project.id);
            }}
          >
            Delete
          </DeleteButton>
        </ProjectCard>
      ))}
    </ProjectsContainer>
  );
};

export default ProjectsList;
