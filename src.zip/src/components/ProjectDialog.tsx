import React, { useState } from 'react';

export default function ProjectDialog({ onClose, onCreate }: { onClose: () => void; onCreate: (project: any) => void }) {
  const [projectName, setProjectName] = useState('');
  const [description, setDescription] = useState('');
  const [context, setContext] = useState('');
  const [color, setColor] = useState('blue');

  const handleCreate = () => {
    onCreate({ projectName, description, context, color });
    onClose();
  };

  return (
    <div className="dialog">
      <h2>New Project</h2>
      <input
        type="text"
        placeholder="Enter project name..."
        value={projectName}
        onChange={(e) => setProjectName(e.target.value)}
      />
      <textarea
        placeholder="Brief description of the project..."
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />
      <textarea
        placeholder="Additional context for the project..."
        value={context}
        onChange={(e) => setContext(e.target.value)}
      />
      <div className="color-picker">
        {['blue', 'green', 'red', 'yellow', 'purple'].map((c) => (
          <button
            key={c}
            style={{ backgroundColor: c }}
            onClick={() => setColor(c)}
            className={color === c ? 'selected' : ''}
          />
        ))}
      </div>
      <button onClick={handleCreate}>Create Project</button>
      <button onClick={onClose}>Cancel</button>
    </div>
  );
}
