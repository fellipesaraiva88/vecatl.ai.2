'use client';
import React, { useRef, useEffect, useState } from 'react';
import styled from 'styled-components';
import { motion } from 'framer-motion';
import { FaRobot, FaTrash } from 'react-icons/fa';
import { useRouter } from 'next/router';

const ChatContainer = styled.div`
  background: rgba(30, 30, 30, 0.9);
  border: 1px solid #2a2a2a;
  border-radius: 18px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
  display: flex;
  flex-direction: column;
  height: 540px;
  width: 100%;
  max-width: 560px;
  margin: auto;
  overflow: hidden;
`;

const ChatHeader = styled.div`
  padding: 16px 24px;
  font-size: 1.2em;
  font-weight: bold;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #1e1e1e;
  color: #fff;
  border-bottom: 1px solid #333;
`;

const HeaderLeft = styled.div`
  display: flex;
  align-items: center;
  gap: 10px;
`;

const ClearButton = styled.button`
  background: #ff4d4d;
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: 8px 12px;
  font-size: 14px;
  cursor: pointer;
  transition: background 0.2s;
  display: flex;
  align-items: center;
  gap: 6px;

  &:hover {
    background: #d43f3f;
  }
`;

const ChatBody = styled.div`
  flex: 1;
  overflow-y: auto;
  padding: 18px 24px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  background: #121212;
`;

const MessageBubble = styled(motion.div)<{ role: string }>`
  align-self: ${({ role }) => (role === 'user' ? 'flex-end' : 'flex-start')};
  background: ${({ role }) => (role === 'user' ? '#007bff' : '#2e2e2e')};
  color: ${({ role }) => (role === 'user' ? '#fff' : '#ccc')};
  padding: 12px 16px;
  border-radius: 14px;
  max-width: 75%;
  font-size: 15px;
  line-height: 1.5;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
  word-break: break-word;
`;

const TypingIndicator = styled.div`
  color: #888;
  font-style: italic;
  font-size: 14px;
  margin-top: 4px;
  align-self: flex-start;
`;

const ChatInputContainer = styled.div`
  display: flex;
  padding: 16px 24px;
  border-top: 1px solid #2a2a2a;
  background: #1e1e1e;
`;

const ChatInput = styled.input`
  flex: 1;
  border: 1px solid #444;
  border-radius: 10px;
  padding: 12px 14px;
  background: #2e2e2e;
  color: #fff;
  font-size: 15px;
  outline: none;
  transition: border 0.2s ease;

  &:focus {
    border-color: #007bff;
  }
`;

const SendButton = styled.button`
  background: #007bff;
  color: #fff;
  font-weight: 500;
  font-size: 15px;
  border-radius: 10px;
  padding: 12px 20px;
  margin-left: 10px;
  border: none;
  cursor: pointer;
  transition: background 0.2s;

  &:hover {
    background: #0056b3;
  }
`;

const LikeButton = styled.button`
  margin: 0 auto 16px;
  padding: 10px 20px;
  border: none;
  background: #28a745;
  color: white;
  font-size: 15px;
  font-weight: 500;
  border-radius: 10px;
  cursor: pointer;
  transition: background 0.2s;

  &:hover {
    background: #218838;
  }
`;

const ChatAssistant = () => {
  const router = useRouter();
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const chatBodyRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatBodyRef.current) {
      chatBodyRef.current.scrollTop = chatBodyRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMsg = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    try {
      const res = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg],
          mode: 'Assistant',
        }),
      });
      const data = await res.json();
      setMessages((prev) => [...prev, { role: 'assistant', content: data.result }]);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setLoading(false);
    }
  };

  const clearChat = () => {
    setMessages([]);
  };

  const navigateToIdeaBox = () => {
    router.push('/ideas');
  };

  return (
    <>
      <ChatContainer>
        <ChatHeader>
          <HeaderLeft>
            <FaRobot />
            AI Chat Assistant
          </HeaderLeft>
          <ClearButton onClick={clearChat}>
            <FaTrash />
            Clear Chat
          </ClearButton>
        </ChatHeader>

        <ChatBody ref={chatBodyRef}>
          {messages.length === 0 && (
            <TypingIndicator>Ask anything…</TypingIndicator>
          )}
          {messages.map((msg, index) => (
            <MessageBubble
              key={index}
              role={msg.role}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              {msg.content}
            </MessageBubble>
          ))}
          {loading && <TypingIndicator>Typing...</TypingIndicator>}
        </ChatBody>

        <ChatInputContainer>
          <ChatInput
            value={input}
            placeholder="Type your message..."
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          />
          <SendButton onClick={sendMessage}>Send</SendButton>
        </ChatInputContainer>
      </ChatContainer>
      <LikeButton onClick={navigateToIdeaBox}>Like This</LikeButton>
    </>
  );
};

export default ChatAssistant;
