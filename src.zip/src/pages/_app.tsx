import '../styles/global.css';
import { ThemeProvider } from 'styled-components';
import Sidebar from '@/components/Sidebar';
import ChatScreen from '@/components/ChatScreen';

const theme = {};

import type { AppProps } from 'next/app';

function MyApp({ Component, pageProps }: AppProps) {
  return (
    <ThemeProvider theme={theme}>
      <Sidebar />
      <ChatScreen />
      <Component {...pageProps} />
    </ThemeProvider>
  );
}

export default MyApp;
